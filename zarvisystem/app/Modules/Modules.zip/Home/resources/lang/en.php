<?php

return [
    'welcome' => 'Welcome, this is Home module.'
];
