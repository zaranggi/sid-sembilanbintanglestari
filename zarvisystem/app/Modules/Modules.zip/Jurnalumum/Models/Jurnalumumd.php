<?php
namespace App\Modules\Jurnalumum\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * @property array|null|string name
 */
class Jurnalumumd extends Model {
    protected $table = 'jurnalid';
    public $timestamps = true;
  
}
