<?php
namespace App\Modules\Kprk\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/** 
 * @property array|null|string name
 */
class Mtrankonsumen extends Model {
    protected $table = 'mtran_konsumen';
    public $timestamps = true;
 

	
}
