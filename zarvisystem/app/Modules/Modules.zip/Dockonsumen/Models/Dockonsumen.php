<?php
namespace App\Modules\Dockonsumen\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * @property array|null|string name
 */
class Dockonsumen extends Model {
    protected $table = 'jenis_doc_konsumen';
    public $timestamps = true;

 	 
}
 
