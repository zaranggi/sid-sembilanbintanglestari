<?php
namespace App\Modules\Dockonsumen\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

/**
 * @property array|null|string name
 */
class Jenislegal extends Model {
    protected $table = 'm_jenis_legalformal';
    public $timestamps = true;


}

